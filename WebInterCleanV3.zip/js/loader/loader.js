// Loading Initial Page
// $('body').append('<div class="loader-container"><div id="loading"></div></div>');
// $(window).on('load', function(){
//   setTimeout(removeLoader, 2 * 3000);
// });
// function removeLoader(){
//     $( ".loader-container" ).fadeOut(500, function() {
//       $( ".loader-container" ).remove();
//       // window.location="https://www.facebook.com/";
//     });
// }
// // Fin Loading Initial Page