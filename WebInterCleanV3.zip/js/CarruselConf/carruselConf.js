$('.carousel').carousel({
    interval: 3500,
    pause:false
});

